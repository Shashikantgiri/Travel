import 'package:flutter/material.dart';
import 'package:liquid_pull_to_refresh/liquid_pull_to_refresh.dart';
import 'package:page_transition/page_transition.dart';

class Pull extends StatefulWidget {
  const Pull({super.key});

  @override
  State<Pull> createState() => _PullState();
}

class _PullState extends State<Pull> {
  Future<void> _handleRefresh() async {
    // Simulate loading data, replace this with your actual data loading logic
    await Future.delayed(Duration(seconds: 1));

    Navigator.push(
        context,
        PageTransition(
          child: Content(),
          type: PageTransitionType.bottomToTop,
          duration: Duration(seconds: 3),
        ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Welcome Foreign Escapes",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w400),
        ),
        backgroundColor: Colors.deepPurple[200],
      ),
      backgroundColor: Colors.deepPurple[200],
      body: LiquidPullToRefresh(
        onRefresh: _handleRefresh,
        color: Colors.deepPurple[100],
        height: 400,
        child: GestureDetector(
          onVerticalDragEnd: (details) {
            if (details != null && details.primaryVelocity != null) {
              if (details.primaryVelocity! > 0) {
                // Swipe down gesture detected, initiate the refresh
                _handleRefresh();
              }
            }
          },
          child: ListView(
            children: [
              Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(15),
                    child: Container(
                      height: 600,
                      color: Colors.deepPurple[200],
                      child: Image.asset(
                          'assets/p.jpg'), // Replace with your image path
                    ),
                  ),
                  SizedBox(height: 50), // Spacer
                  Text(
                    'Explore the world, discover yourself',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                  Text(
                    'Drag down to Search cities',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w400,
                    ),
                  ),
                ],
              ),

              // Your list items here
            ],
          ),
        ),
      ),
    );
  }
}

class Content extends StatefulWidget {
  const Content({super.key});

  @override
  State<Content> createState() => _ContentState();
}

class _ContentState extends State<Content> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Cities",
          style: TextStyle(fontSize: 20, fontWeight: FontWeight.w400),
        ),
        backgroundColor: Colors.deepPurple[200],
      ),
      backgroundColor: Colors.deepPurple[200],
      body: ListView(
        children: [
          _buildImageContainer(),
          _buildImageContainerone(),
          _buildImageContainertwo(),
          _buildImageContainerfour(),
        ],
      ),
    );
  }

  Widget _buildImageContainer() {
    return Padding(
      padding: EdgeInsets.all(25.0),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: Container(
              height: 235,
              color: Colors.deepPurple[200],
              child: Image.asset(
                  'assets/THAILAND.jpg'), // Replace with your image path
            ),
          ),
          SizedBox(height: 10), // Spacer
          Text(
            'Thailand',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImageContainerone() {
    return Padding(
      padding: EdgeInsets.all(25.0),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: Container(
              height: 235,
              color: Colors.deepPurple[200],
              child: Image.asset(
                  'assets/ectraone.jpg'), // Replace with your image path
            ),
          ),
          SizedBox(height: 10), // Spacer
          Text(
            'Extraone',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImageContainertwo() {
    return Padding(
      padding: EdgeInsets.all(25.0),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: Container(
              height: 235,
              color: Colors.deepPurple[200],
              child: Image.asset(
                  'assets/vietnam.png'), // Replace with your image path
            ),
          ),
          SizedBox(height: 10), // Spacer
          Text(
            'Vietnam',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildImageContainerfour() {
    return Padding(
      padding: EdgeInsets.all(25.0),
      child: Column(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(15),
            child: Container(
              height: 235,
              color: Colors.deepPurple[200],
              child:
                  Image.asset('assets/use.jpg'), // Replace with your image path
            ),
          ),
          SizedBox(height: 10), // Spacer
          Text(
            'Get More',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
    );
  }
}
